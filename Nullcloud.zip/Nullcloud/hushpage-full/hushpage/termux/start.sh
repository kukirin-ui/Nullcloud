#!/data/data/com.termux/files/usr/bin/bash
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
TOKEN="$(cat "$HOME/.hushpage-token")"
THREADS="${THREADS:-4}"
termux-wake-lock 2>/dev/null
pkill -f "llama-server.*--port 8081" 2>/dev/null
pkill -f "server/server.py" 2>/dev/null
nohup llama-server -m "$HOME/hushpage-models/model.gguf" -c 4096 -t "$THREADS" \
  --host 127.0.0.1 --port 8081 > "$HOME/hushpage-llm.log" 2>&1 &
echo -n "Loading model"
for i in $(seq 1 90); do
  curl -s http://127.0.0.1:8081/health 2>/dev/null | grep -q ok && break
  echo -n "."; sleep 2
done
echo
TOKEN="$TOKEN" nohup python "$ROOT/server/server.py" > "$HOME/hushpage-api.log" 2>&1 &
sleep 2
echo "Hushpage is running."
echo "Web UI:  http://127.0.0.1:8080  (open in any browser on this phone)"
echo "Token:   $TOKEN"
