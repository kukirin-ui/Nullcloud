#!/data/data/com.termux/files/usr/bin/bash
# One-time setup. Run: bash termux/setup.sh
set -e
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
MODELS="$HOME/hushpage-models"; mkdir -p "$MODELS"
# Default: Llama 3.2 3B Instruct Q4_K_M (~2 GB, needs ~6 GB RAM phone). Weaker phone: use a 1B model, see README.
MODEL_URL="${MODEL_URL:-https://huggingface.co/bartowski/Llama-3.2-3B-Instruct-GGUF/resolve/main/Llama-3.2-3B-Instruct-Q4_K_M.gguf}"

pkg update -y && pkg upgrade -y
pkg install -y python curl wget jq termux-api unzip
if ! command -v llama-server >/dev/null; then
  pkg install -y llama-cpp 2>/dev/null || pkg install -y llama.cpp 2>/dev/null || {
    echo "!! llama.cpp package not found in your Termux repo. See README > Troubleshooting (build from source)."; exit 1; }
fi
pip install -r "$ROOT/server/requirements.txt"

if [ ! -f "$MODELS/model.gguf" ]; then
  wget -c -O "$MODELS/model.gguf.part" "$MODEL_URL" && mv "$MODELS/model.gguf.part" "$MODELS/model.gguf"
fi
[ -f "$HOME/.hushpage-token" ] || head -c 12 /dev/urandom | od -An -tx1 | tr -d ' \n' > "$HOME/.hushpage-token"

# "Share a link to Termux" -> private summary
mkdir -p "$HOME/bin"
cp "$ROOT/termux/termux-url-opener" "$HOME/bin/termux-url-opener"
chmod +x "$HOME/bin/termux-url-opener" "$ROOT/termux/start.sh" "$ROOT/termux/stop.sh"
echo "$ROOT" > "$HOME/.hushpage-root"

echo
echo "Setup done."
echo "Your token: $(cat "$HOME/.hushpage-token")"
echo "Start:      bash $ROOT/termux/start.sh"
