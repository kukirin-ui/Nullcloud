#!/usr/bin/env python3
"""Hushpage server: page text or URL -> local LLM (OpenAI-compatible API) -> streamed answer.
Works with llama.cpp's llama-server (Termux/desktop) and Ollama (desktop). Nothing leaves your device
except the page fetch you explicitly ask for in URL mode."""
import datetime, hmac, ipaddress, json, os, pathlib, re, socket, sys
from html.parser import HTMLParser
from urllib.parse import urlparse

import requests
from flask import Flask, Response, jsonify, request, send_from_directory
from flask_cors import CORS

HOST = os.environ.get("HOST", "127.0.0.1")
PORT = int(os.environ.get("PORT", "8080"))
LLM_URL = os.environ.get("LLM_URL", "http://127.0.0.1:8081/v1/chat/completions")
MODEL = os.environ.get("MODEL", "local")
TOKEN = os.environ.get("TOKEN", "")
MAX_CHARS = int(os.environ.get("MAX_CHARS", "6000"))
MAX_TOKENS = int(os.environ.get("MAX_TOKENS", "400"))
NOTES_DIR = os.environ.get("NOTES_DIR", "")  # opt-in: save results as Markdown (e.g. an Obsidian vault folder)
ARCHIVE = os.environ.get("ARCHIVE", "") == "1"  # opt-in: also keep the raw HTML next to each note

if not TOKEN:
    sys.exit("Set TOKEN first, e.g.: TOKEN=$(head -c 12 /dev/urandom | od -An -tx1 | tr -d ' \\n') python server.py")

app = Flask(__name__)
CORS(app, origins=[r"^chrome-extension://.*$", r"^moz-extension://.*$"])

MODES = {
    "summary": "Summarize the page in 3-5 concise bullet points, then one sentence on why it matters.",
    "facts": "List the key facts, numbers, names and dates in the page as bullets. Add nothing that is not in the page.",
    "claims": "List the main claims the page makes. For each, say whether the page itself gives evidence for it. Stay neutral.",
    "translate": "Translate the main content of the page into {lang}.",
    "eli5": "Explain the page in simple words a 12-year-old would understand, in at most 6 sentences.",
}


class _Text(HTMLParser):
    SKIP = {"script", "style", "noscript", "svg", "head", "nav", "footer", "iframe"}
    BREAK = {"p", "div", "br", "li", "h1", "h2", "h3", "h4", "tr", "section", "article"}

    def __init__(self):
        super().__init__()
        self.out, self.skip = [], 0

    def handle_starttag(self, tag, attrs):
        if tag in self.SKIP:
            self.skip += 1
        if tag in self.BREAK:
            self.out.append("\n")

    def handle_endtag(self, tag):
        if tag in self.SKIP and self.skip:
            self.skip -= 1
        if tag in self.BREAK:
            self.out.append("\n")

    def handle_data(self, data):
        if not self.skip and data.strip():
            self.out.append(data.strip() + " ")


def fetch_text(url):
    p = urlparse(url)
    if p.scheme not in ("http", "https") or not p.hostname:
        raise ValueError("Only http/https URLs are supported.")
    for info in socket.getaddrinfo(p.hostname, None):
        ip = ipaddress.ip_address(info[4][0])
        if ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_reserved:
            raise ValueError("Private/local addresses are blocked.")
    r = requests.get(url, timeout=20, headers={"User-Agent": "Mozilla/5.0 (Hushpage)"})
    r.raise_for_status()
    parser = _Text()
    parser.feed(r.text[:2_000_000])
    return re.sub(r"\n\s*\n+", "\n", "".join(parser.out)).strip(), r.text


def save_note(url, mode, output, raw):
    """Write a Markdown note (+ optional raw HTML archive). Local files only; never raises."""
    try:
        base = pathlib.Path(NOTES_DIR).expanduser()
        base.mkdir(parents=True, exist_ok=True)
        now = datetime.datetime.now()
        host = re.sub(r"[^a-z0-9]+", "-", (urlparse(url).hostname or "note").lower()).strip("-")
        name = f"{now:%Y-%m-%d-%H%M%S}-{host}"
        meta = [f'source: "{url}"', f"date: {now.isoformat(timespec='seconds')}", f"mode: {mode}", "tags: [hushpage]"]
        if ARCHIVE and raw:
            (base / "archive").mkdir(exist_ok=True)
            (base / "archive" / f"{name}.html").write_text(raw, encoding="utf-8")
            meta.append(f"archive: archive/{name}.html")
        (base / f"{name}.md").write_text("---\n" + "\n".join(meta) + "\n---\n\n" + output.strip() + "\n", encoding="utf-8")
    except Exception as e:  # noqa: BLE001
        print("save_note failed:", e, file=sys.stderr)


def authorized():
    return hmac.compare_digest(request.headers.get("X-Token", ""), TOKEN)


@app.get("/")
def ui():
    return send_from_directory(os.path.dirname(os.path.abspath(__file__)), "ui.html")


@app.get("/health")
def health():
    return jsonify(ok=True)


@app.post("/analyze")
def analyze():
    if not authorized():
        return jsonify(error="Wrong or missing token."), 401
    d = request.get_json(force=True, silent=True) or {}
    try:
        text, raw = (d.get("text") or "").strip(), ""
        if not text and d.get("url"):
            text, raw = fetch_text(d["url"])
    except Exception as e:  # noqa: BLE001
        return jsonify(error=f"Could not read URL: {e}"), 400
    if len(text) < 20:
        return jsonify(error="No text to analyze."), 400

    mode, q, lang = d.get("mode", "summary"), (d.get("q") or "").strip(), (d.get("lang") or "").strip()
    task = q if (mode == "ask" and q) else MODES.get(mode, MODES["summary"]).format(lang=lang or "the language of the page")
    system = ("You are a private on-device assistant. Use only the PAGE text. "
              "If the answer is not in the page, say so. "
              + (f"Reply in {lang}." if lang else "Reply in the language of the page unless the task says otherwise."))
    payload = {
        "model": MODEL,
        "stream": True,
        "temperature": 0.2,
        "max_tokens": MAX_TOKENS,
        "messages": [
            {"role": "system", "content": system},
            {"role": "user", "content": f"PAGE:\n{text[:MAX_CHARS]}\n\nTASK: {task}"},
        ],
    }

    def gen():
        acc = []
        try:
            with requests.post(LLM_URL, json=payload, stream=True, timeout=(5, 600)) as r:
                r.raise_for_status()
                for line in r.iter_lines():
                    if not line.startswith(b"data:"):
                        continue
                    chunk = line[5:].strip()
                    if chunk == b"[DONE]":
                        break
                    try:
                        delta = json.loads(chunk)["choices"][0]["delta"].get("content")
                    except (ValueError, KeyError, IndexError):
                        continue
                    if delta:
                        acc.append(delta)
                        yield delta
            if NOTES_DIR and acc:
                save_note(d.get("url") or "", mode, "".join(acc), raw)
        except Exception as e:  # noqa: BLE001
            yield f"\n[Model server not reachable: {e}. Is it running? See README > Troubleshooting.]"

    return Response(gen(), mimetype="text/plain; charset=utf-8",
                    headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})


if __name__ == "__main__":
    if HOST not in ("127.0.0.1", "localhost"):
        print(f"WARNING: listening on {HOST}. Anyone on that network can reach the API (token required).")
    app.run(host=HOST, port=PORT, threaded=True)
