#!/usr/bin/env bash
# macOS / Linux. Needs Ollama (https://ollama.com/download) and Python 3.
set -e
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
MODEL="${MODEL:-llama3.2:3b}"
command -v ollama >/dev/null || { echo "Install Ollama first: https://ollama.com/download"; exit 1; }
ollama list >/dev/null 2>&1 || { (ollama serve >/dev/null 2>&1 &); sleep 3; }
ollama pull "$MODEL"
python3 -m pip install -q -r "$ROOT/server/requirements.txt"
[ -f "$HOME/.hushpage-token" ] || head -c 12 /dev/urandom | od -An -tx1 | tr -d ' \n' > "$HOME/.hushpage-token"
echo "Token: $(cat "$HOME/.hushpage-token")"
LLM_URL=http://127.0.0.1:11434/v1/chat/completions MODEL="$MODEL" TOKEN="$(cat "$HOME/.hushpage-token")" \
  python3 "$ROOT/server/server.py"
