@echo off
rem Windows. Needs Ollama (https://ollama.com/download) and Python 3.
set MODEL=llama3.2:3b
where ollama >nul 2>&1 || (echo Install Ollama first: https://ollama.com/download & pause & exit /b 1)
ollama pull %MODEL%
python -m pip install -q -r "%~dp0..\server\requirements.txt"
if not exist "%USERPROFILE%\.hushpage-token" powershell -NoProfile -Command "[guid]::NewGuid().ToString('N').Substring(0,24) | Set-Content -NoNewline $env:USERPROFILE\.hushpage-token"
set /p TOKEN=<"%USERPROFILE%\.hushpage-token"
set LLM_URL=http://127.0.0.1:11434/v1/chat/completions
echo Your token: %TOKEN%
python "%~dp0..\server\server.py"
