const $ = (id) => document.getElementById(id);
const API = "http://127.0.0.1:8080";
const store = chrome.storage.local;

function toggleAsk() { $("q").style.display = $("mode").value === "ask" ? "block" : "none"; }

(async () => {
  const s = await store.get(["token", "lang", "mode"]);
  $("token").value = s.token || "";
  $("lang").value = s.lang || "";
  $("mode").value = s.mode || "summary";
  toggleAsk();
})();
$("mode").addEventListener("change", toggleAsk);

$("copy").addEventListener("click", () => navigator.clipboard.writeText($("out").textContent));

$("go").addEventListener("click", async () => {
  const out = $("out");
  const token = $("token").value.trim();
  const lang = $("lang").value.trim();
  const mode = $("mode").value;
  await store.set({ token, lang, mode });
  if (!token) { out.textContent = "Paste your token first (printed by the setup/start script)."; return; }
  out.textContent = "Reading page...";
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    const [res] = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: () => ({
        sel: String(getSelection()).trim(),
        body: document.body ? document.body.innerText : "",
        title: document.title
      })
    });
    const page = res.result;
    const text = "Title: " + page.title + "\n\n" + (page.sel.length > 40 ? page.sel : page.body);
    out.textContent = "Thinking (runs on your device)...";
    const r = await fetch(API + "/analyze", {
      method: "POST",
      headers: { "Content-Type": "application/json", "X-Token": token },
      body: JSON.stringify({ text, mode, q: $("q").value, lang, url: tab.url })
    });
    if (r.status === 401) { out.textContent = "Wrong token."; return; }
    if (!r.ok) { out.textContent = (await r.json().catch(() => ({}))).error || ("Error " + r.status); return; }
    const reader = r.body.getReader();
    const dec = new TextDecoder();
    out.textContent = "";
    for (;;) {
      const { done, value } = await reader.read();
      if (done) break;
      out.textContent += dec.decode(value, { stream: true });
    }
  } catch (e) {
    out.textContent = "Cannot reach the local server (" + e.message + "). Is it running? See README > Troubleshooting.";
  }
});

$("speak").addEventListener("click", () => {
  if (speechSynthesis.speaking) { speechSynthesis.cancel(); return; }
  speechSynthesis.speak(new SpeechSynthesisUtterance($("out").textContent));
});
