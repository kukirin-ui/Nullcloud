# Hushpage - private AI for any page, running on your own device

Summarize, fact-extract, translate or question any web page with a local model.
Page text goes only to `127.0.0.1` on your own phone or computer. No account, no API key, no cloud AI.

Three ways to use it, same server:
1. **Browser extension** (Chrome, Edge, Brave, Firefox) - click, get answer.
2. **Web UI** at `http://127.0.0.1:8080` - works in ANY browser, paste a link or text.
3. **Android share sheet** - share a link to Termux, get a summary notification (Termux only).

## Quick start - desktop (2 min)
1. Install [Ollama](https://ollama.com/download) and Python 3.
2. Run `desktop/start.sh` (macOS/Linux) or `desktop\start.bat` (Windows). It pulls `llama3.2:3b`, creates a token, starts the server.
3. Load the extension: open `chrome://extensions` -> Developer mode -> **Load unpacked** -> select `extension/`.
4. Open any page, click the Hushpage icon, paste the token once, press **Run**.

## Quick start - Android (Termux)
Needs: ~6 GB RAM phone (use a 1B model on less), ~3 GB free storage, Wi-Fi for the one-time download.
1. Install Termux and Termux:API from **F-Droid** (not Play Store): https://f-droid.org/packages/com.termux/ and https://f-droid.org/packages/com.termux.api/
2. In Termux: `pkg install -y git && git clone https://github.com/YOU/hushpage && bash hushpage/termux/setup.sh`
   (zip instead of git: `termux-setup-storage`, copy the zip to Downloads, then `pkg install -y unzip && unzip ~/storage/downloads/hushpage-full.zip -d ~ && bash ~/hushpage/termux/setup.sh`)
3. `bash ~/hushpage/termux/start.sh` -> prints your token. Open `http://127.0.0.1:8080` in any browser, paste the token, paste a link, Run.
4. Share sheet: in any app, Share -> **Termux** -> summary appears in Termux and as a notification.
5. Android Settings > Apps > Termux > Battery > Unrestricted, so it is not killed.

### Extension on Android phones
Kiwi Browser is discontinued (archived January 2025). Options:
- **Web UI / share sheet** (no extension needed) - works today in any browser.
- **Firefox for Android** - supports add-ons from addons.mozilla.org. Publish there (free) or submit as "unlisted" for a signed `.xpi`. Localhost access may need to be allowed in the add-on's permissions.
- **Edge (Canary) for Android** - installs extensions by Edge Add-ons ID after you publish there.

## Features
- **Share-sheet menu** (Android): Share a link to Termux, then choose Summarize / Summarize + read aloud / Key facts / Explain simply / Claims check / Translate.
- **Read aloud**: share-sheet option uses Android's TTS (`termux-tts-speak`); web UI and extension have a Read aloud button (browser speech). Fully offline only if an offline voice is installed (Android Settings > Text-to-speech).
- **Markdown notes** (opt-in): `NOTES_DIR=~/storage/shared/Documents/Vault` saves every result as a `.md` file with source URL, date and mode in front matter. Point Obsidian or Logseq at that folder. Run `termux-setup-storage` first on Android.
- **Offline archive** (opt-in): add `ARCHIVE=1` to also keep the downloaded page HTML in `NOTES_DIR/archive/` (URL mode only). Respect the site's terms and copyright; for personal use.
- Set these in `termux/start.sh` or export before starting, e.g. `export NOTES_DIR=... ARCHIVE=1`.

## Benchmark (measure on YOUR phone before posting numbers)
`bash termux/bench.sh 20` -> end-to-end tok/s, time per article, battery % and temperature change. Use airplane mode, charger unplugged, same brightness. Battery % is coarse: use 20+ runs. Publish your device, model, and result table here:

| Device | Model | tok/s | s/article | Battery drop / 20 articles | Temp change |
|---|---|---|---|---|---|
| (fill in) | Llama-3.2-3B Q4_K_M | | | | |

## How it compares (public READMEs, Oct 2026 - re-check before posting)
| | Hushpage | Page Assist |
|---|---|---|
| Browser extension (Chrome/Firefox) | yes | yes |
| Android share-sheet to private summary | yes (Termux) | not offered |
| Runs fully on a phone (Termux server + model) | yes | no setup for this |
| Works in any browser via web UI | yes | no |
| Read aloud | yes | - |
| Markdown / Obsidian export | yes | - |
| Full chat UI, history, file chat | no (single-shot actions) | yes |
| Model backends | llama.cpp, Ollama, any OpenAI-compatible | Ollama, OpenAI-compatible |
Choose Page Assist for desktop chat. Choose Hushpage for phone-first, share-and-done use.

## iOS (via Shortcuts, untested)
iPhones cannot run Termux. Run Hushpage on a computer you own and reach it over Tailscale (https://tailscale.com):
1. Computer: `HOST=<its tailscale IP> desktop/start.sh` (never `0.0.0.0` on public networks). Note the token.
2. iPhone: install Tailscale, join the same tailnet.
3. Shortcuts app -> new shortcut -> enable "Show in Share Sheet" (accept URLs) -> **Get Contents of URL**: URL `http://<tailscale IP>:8080/analyze`, Method POST, Header `X-Token: <token>`, Request Body JSON `{ "url": Shortcut Input, "mode": "summary" }` -> **Show Result** (or **Speak Text**).
The response arrives as plain text when generation finishes.

## Roadmap (not in v1)
Daily digest (queue links, summarize overnight), multimodal/screenshot input, PDF input, saved-page search.

## Models
| Device | Model | Notes |
|---|---|---|
| Phone, 6+ GB RAM | Llama-3.2-3B-Instruct Q4_K_M (default, ~2 GB) | ~5-15 tokens/s typical |
| Phone, 4 GB RAM | A 1B Q4 GGUF, e.g. Llama-3.2-1B-Instruct | `MODEL_URL=<gguf url> bash termux/setup.sh` |
| Desktop | `llama3.2:3b` via Ollama (default) or larger | `MODEL=qwen2.5:7b desktop/start.sh` |

Check the license of the model you choose before commercial use. Default model repo: https://huggingface.co/bartowski/Llama-3.2-3B-Instruct-GGUF

## Publish the extension (to get real users)
1. Replace `hushpage@CHANGE-ME.example` in `extension/manifest.json` with your own id; rename the product if you like.
2. Zip the **contents** of `extension/` (manifest at the zip root; `hushpage-extension.zip` is ready).
3. Chrome Web Store: https://chrome.google.com/webstore/devconsole (one-time developer registration fee)
4. Firefox Add-ons (free): https://addons.mozilla.org/developers/
5. Edge Add-ons (free): https://partner.microsoft.com/dashboard/microsoftedge/
6. Listing must state: reads page text only when you click; sends it only to `127.0.0.1`; collects nothing.

## Troubleshooting
- **"Cannot reach the local server"**: server not running. Termux: `bash termux/start.sh`; read `~/hushpage-api.log` and `~/hushpage-llm.log`.
- **`llama-cpp` package not found**: `pkg install -y git cmake clang && git clone https://github.com/ggml-org/llama.cpp && cd llama.cpp && cmake -B build && cmake --build build --target llama-server -j$(nproc)`, then put `build/bin` on your PATH.
- **Slow first answer on phone**: the model reads the whole page first. Lower `MAX_CHARS` (default 6000) or use a 1B model.
- **Wrong token**: it is in `~/.hushpage-token`.

## Privacy, precisely
- Extension reads the active tab only when you press Run (`activeTab`).
- Text goes to `127.0.0.1:8080` -> your local model. The server stores and logs nothing.
- URL mode (web UI / share sheet): your device downloads that page itself, like opening it in a browser.
- Server requires a token, blocks private-network URLs, binds to localhost by default.

## Configuration (env vars)
`TOKEN` (required), `HOST`, `PORT`, `LLM_URL`, `MODEL`, `MAX_CHARS`, `MAX_TOKENS`.

MIT licensed.
