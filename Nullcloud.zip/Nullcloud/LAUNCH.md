# Launch plan (worldwide)

## Honest positioning
Local-LLM page assistants already exist (e.g. Page Assist: Chrome + Firefox, Ollama, thousands of GitHub stars). Do not claim "first".
Your real angles:
1. **Pocket private AI**: runs on a phone, works in airplane mode on pages already open. Few projects show this.
2. **Share any link -> private summary** on Android, no extension needed.
3. **One setup script**, three entry points (extension, web UI, share sheet).
Tagline: "AI that reads the web for you - without the web reading you."
Never say "air-gapped" (the phone is online). Say "on-device, no cloud AI".

## Assets to make before posting (1 day)
- 20-second screen recording: phone in airplane mode -> open article -> summary streams in. This is the whole marketing.
- 1 GIF of the desktop extension. 1 screenshot of the share-sheet notification.
- GitHub repo `hushpage`: README top = GIF + 3-line pitch + install block. Topics: local-llm, privacy, termux, browser-extension, llama-cpp, ollama.
- Check name/domain/trademark availability (GitHub, stores) before publishing.

## Pre-launch gates (do not post before these)
1. Run `termux/bench.sh 20` on 2 phones; paste real numbers into README. Expect the Hacker News question "what does it do to my battery?"
2. Verify the README comparison table against current competitor READMEs.
3. Test the share-sheet menu, read aloud, and Markdown export on a real phone (they are untested on-device).
4. Add README "Features" GIFs: share menu, read aloud, note appearing in Obsidian.

## Deferred on purpose (v1.1+ / Pro)
Daily digest, vision models and PDF input: each adds setup weight or heavy RAM use on phones. Ship the fast, simple core first; use real feedback to pick the next one.

## Posting order (post when you can answer comments for 6 hours)
| Day | Where | Angle |
|---|---|---|
| 1 (Tue-Thu, ~14:00-16:00 UTC) | Hacker News Show HN: https://news.ycombinator.com/showhn.html | "Show HN: Hushpage - summarize any page with an LLM running on your phone" |
| 1 | r/LocalLLaMA | numbers: model, tokens/s on your phone, RAM |
| 2 | r/termux, r/selfhosted, r/privacy | one tailored post each, not copy-paste |
| 2 | r/androidapps, XDA forums | share-sheet angle |
| 3 | X, Mastodon, Bluesky thread with the video | demo, how, numbers, link |
| 4-7 | Product Hunt (https://www.producthunt.com), Dev.to write-up "I ran an LLM page reader on my phone" | story + benchmarks |
| 7+ | Store listings live; add store links to README | steady installs |

## Show HN template
Title: Show HN: Hushpage - private page summarizer running a local LLM on your phone
Body: what it does (2 lines) / why (privacy, offline) / how (extension -> Flask -> llama.cpp) / honest limits (3B model, 5-15 tok/s, small-model mistakes) / feedback wanted. No hype words. Reply to every comment.

## Money (realistic)
- Free MIT core for distribution. GitHub Sponsors: https://github.com/sponsors ; Ko-fi.
- Later paid "Pro" (one-time license, Gumroad https://gumroad.com or Lemon Squeezy https://www.lemonsqueezy.com): saved-page library with search, PDF input, prompt presets, phone as private AI server for your laptop over Tailscale (https://tailscale.com).
- Setup/consulting for privacy-sensitive teams (law, journalism, clinics) is the likeliest early revenue.

## Odds (my estimates, not data; assumes you execute this plan)
| Outcome within 90 days | Chance |
|---|---|
| Some traction (>=50 stars or >=200 installs) | 35-45% |
| One Show HN reaches the front page | ~10% |
| >=1,000 GitHub stars | 5-10% |
| >=10,000 stars / mainstream "viral" | <1% |
| >=$1,000/month revenue by month 6 | 3-5% |
Odds rise with: a strong airplane-mode video, real benchmark numbers, fast replies, a 60-second install. They fall if setup breaks on common phones - test on 3 devices before launch.

## Risks
- Small-model errors: show "may be wrong" note; never claim accuracy.
- Store review: keep permissions minimal (activeTab, scripting, storage).
- Model licenses differ; link to them, do not bundle weights.
- Termux from F-Droid only; Play Store builds are outdated.
